﻿Import-Module "$PSScriptRoot\HarshPoint.Shellploy.psd1" -Force

$Context = @{
    Url      = 'https://studentslsbforg.sharepoint.com/sites/ia-dev12'
    UserName = 'nu@students.lsbf.org.uk'
    Password = 'Heslo1234'
}

$CTGroup        = 'IADW Trend Analyst'
$CT_Publication = '0x010029a2e4b473ca49939b163bccd17b9088'

Provision @Context {

    Field -Id           '8f6c60bd-6eba-49fa-a1bb-598fcfad8147' `
          -InternalName PublicationDescription `
          -DisplayName  'Description' `
          -Type         Note

    ContentType $CT_Publication 'Publication' $CTGroup {
        FieldRef URL
        FieldRef PublicationDescription
    }
}